# Controller

ControllerApp is a tool that allows you to catch all sorts of UI events like a simple tap on your mobile's screen or a device's acceleration directly in your Python code. 
[documentation](http://www.controllerapp.ml)
