from controller.controller import Controller as Controller_
def Controller(*args):
    c = Controller_()
    return c