# Controller

Controller is both an Android App and a Python Package that enables you to connect your Python Code to a so-called "Controller".
[Gitlab Viarezo](https://gitlab.viarezo.fr/2019hammoudf/controller)
